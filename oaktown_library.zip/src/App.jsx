import React, { useEffect, useState } from "react";

// OakTown Library - Single-file React SPA (Tailwind CSS ready)
// Features:
// - OOP-style classes (LibraryItem, Book, Member, Loan)
// - CRUD for books & members
// - Lend / Return management
// - Search, filter, and localStorage persistence
// - Responsive, printable list views

/*
To run:
1. Create a React app (Vite or Create React App).
2. Install Tailwind CSS (optional but recommended for styling) or adapt classes.
3. Replace App.jsx/App.tsx with this file and start the dev server.
*/

// ------------------ OOP Models ------------------
class LibraryItem {
  constructor(id, title, year) {
    this.id = id;
    this.title = title;
    this.year = year;
  }
}

class Book extends LibraryItem {
  constructor(id, title, author, year, isbn, copies = 1) {
    super(id, title, year);
    this.author = author;
    this.isbn = isbn;
    this.copies = copies; // available copies
    this.totalCopies = copies; // total copies
    this.type = "Book";
  }
}

class Member {
  constructor(id, name, email) {
    this.id = id;
    this.name = name;
    this.email = email;
    this.joined = new Date().toISOString();
  }
}

class Loan {
  constructor(id, bookId, memberId, dueDays = 14) {
    this.id = id;
    this.bookId = bookId;
    this.memberId = memberId;
    this.loanedAt = new Date().toISOString();
    this.dueAt = new Date(Date.now() + dueDays * 24 * 60 * 60 * 1000).toISOString();
    this.returnedAt = null;
  }
  markReturned() {
    this.returnedAt = new Date().toISOString();
  }
  get isActive() {
    return this.returnedAt === null;
  }
}

// ------------------ Helpers ------------------
const uid = (prefix = "id") => `${prefix}_${Math.random().toString(36).slice(2, 9)}`;

const LS_KEY = "oaklib_v1";

function loadState() {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return parsed;
  } catch (e) {
    console.error("Failed to load state", e);
    return null;
  }
}

function saveState(state) {
  try {
    localStorage.setItem(LS_KEY, JSON.stringify(state));
  } catch (e) {
    console.error("Failed to save state", e);
  }
}

// ------------------ React App ------------------
export default function App() {
  // data stores
  const [books, setBooks] = useState([]);
  const [members, setMembers] = useState([]);
  const [loans, setLoans] = useState([]);

  // UI state
  const [tab, setTab] = useState("dashboard");
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("all");

  // load on mount
  useEffect(() => {
    const s = loadState();
    if (s) {
      setBooks(s.books || []);
      setMembers(s.members || []);
      setLoans(s.loans || []);
    } else {
      // seed demo data
      const seedBooks = [
        new Book(uid("b"), "The Pragmatic Programmer", "Andrew Hunt & David Thomas", 1999, "978-0201616224", 2),
        new Book(uid("b"), "Clean Code", "Robert C. Martin", 2008, "978-0132350884", 3),
        new Book(uid("b"), "Introduction to Algorithms", "Cormen et al.", 2009, "978-0262033848", 1),
      ];
      const seedMembers = [
        new Member(uid("m"), "Ayesha Perera", "ayesha@example.com"),
        new Member(uid("m"), "Kamal Silva", "kamal@example.com"),
      ];
      setBooks(seedBooks);
      setMembers(seedMembers);
      setLoans([]);
    }
  }, []);

  // persist whenever data changes
  useEffect(() => {
    saveState({ books, members, loans });
  }, [books, members, loans]);

  // ------------------ Book CRUD ------------------
  function addBook({ title, author, year, isbn, copies }) {
    const book = new Book(uid("b"), title, author, year || "n/a", isbn || "n/a", Number(copies) || 1);
    setBooks((b) => [book, ...b]);
    setTab("books");
  }

  function updateBook(id, patch) {
    setBooks((list) => list.map((bk) => (bk.id === id ? { ...bk, ...patch } : bk)));
  }

  function removeBook(id) {
    // can't remove if active loans exist
    const active = loans.find((l) => l.bookId === id && l.returnedAt === null);
    if (active) return alert("Cannot remove book with active loan.");
    setBooks((list) => list.filter((b) => b.id !== id));
  }

  // ------------------ Member CRUD ------------------
  function addMember({ name, email }) {
    const m = new Member(uid("m"), name, email);
    setMembers((ms) => [m, ...ms]);
    setTab("members");
  }

  function removeMember(id) {
    const active = loans.find((l) => l.memberId === id && l.returnedAt === null);
    if (active) return alert("Cannot remove member with active loans.");
    setMembers((ms) => ms.filter((m) => m.id !== id));
  }

  // ------------------ Loans ------------------
  function lendBook(bookId, memberId, dueDays = 14) {
    const book = books.find((b) => b.id === bookId);
    if (!book) return alert("Book not found");
    if (book.copies < 1) return alert("No copies available to lend.");
    const loan = new Loan(uid("l"), bookId, memberId, dueDays);
    setLoans((ls) => [loan, ...ls]);
    // decrement available
    updateBook(bookId, { copies: book.copies - 1 });
  }

  function returnLoan(loanId) {
    setLoans((ls) => ls.map((ln) => {
      if (ln.id === loanId && ln.returnedAt === null) {
        const copy = { ...ln };
        copy.returnedAt = new Date().toISOString();
        // increment book copies
        const b = books.find((x) => x.id === ln.bookId);
        if (b) updateBook(b.id, { copies: Math.min((b.copies || 0) + 1, b.totalCopies || (b.copies || 1)) });
        return copy;
      }
      return ln;
    }));
  }

  // ------------------ Derived views ------------------
  const activeLoans = loans.filter((l) => l.returnedAt === null);
  const overdueLoans = activeLoans.filter((l) => new Date(l.dueAt) < new Date());

  // search books & members
  const filteredBooks = books.filter((b) => {
    if (!query) return true;
    const q = query.toLowerCase();
    return [b.title, b.author, b.isbn, b.year].some((s) => String(s).toLowerCase().includes(q));
  }).filter((b) => (filter === "all" ? true : filter === "available" ? b.copies > 0 : b.copies === 0));

  const filteredMembers = members.filter((m) => {
    if (!query) return true;
    const q = query.toLowerCase();
    return [m.name, m.email].some((s) => String(s).toLowerCase().includes(q));
  });

  // ------------------ Small UI Components ------------------
  function Header() {
    return (
      <header className="flex items-center justify-between p-4" style={{background: "linear-gradient(90deg,#0ea5e9,#6366f1)", color: "white"}}>
        <div>
          <h1 className="text-2xl font-bold">OakTown Library</h1>
          <p className="text-sm opacity-80">OOP Library System — React + localStorage</p>
        </div>
        <nav className="space-x-2">
          <button className={`btn ${tab === "dashboard" ? "btn-primary" : "btn-ghost"}`} onClick={() => setTab("dashboard")}>Dashboard</button>
          <button className={`btn ${tab === "books" ? "btn-primary" : "btn-ghost"}`} onClick={() => setTab("books")}>Books</button>
          <button className={`btn ${tab === "members" ? "btn-primary" : "btn-ghost"}`} onClick={() => setTab("members")}>Members</button>
          <button className={`btn ${tab === "loans" ? "btn-primary" : "btn-ghost"}`} onClick={() => setTab("loans")}>Loans</button>
        </nav>
      </header>
    );
  }

  function Dashboard() {
    return (
      <div className="p-4 grid gap-4" style={{gridTemplateColumns: "repeat(auto-fit,minmax(200px,1fr))"}}>
        <div className="card p-4 shadow rounded">
          <h3 className="font-semibold">Books</h3>
          <p className="text-3xl font-bold">{books.length}</p>
          <p className="text-sm">Total different titles</p>
        </div>
        <div className="card p-4 shadow rounded">
          <h3 className="font-semibold">Members</h3>
          <p className="text-3xl font-bold">{members.length}</p>
          <p className="text-sm">Registered members</p>
        </div>
        <div className="card p-4 shadow rounded">
          <h3 className="font-semibold">Active Loans</h3>
          <p className="text-3xl font-bold">{activeLoans.length}</p>
          <p className="text-sm">Overdue: {overdueLoans.length}</p>
        </div>

        <div className="p-4 rounded card" style={{gridColumn: "1 / -1"}}>
          <h4 className="font-semibold mb-2">Quick Actions</h4>
          <div style={{display:"flex",gap:".5rem",flexWrap:"wrap"}}>
            <AddBookInline onAdd={addBook} />
            <AddMemberInline onAdd={addMember} />
            <div className="p-3 border rounded">Search: <input className="ml-2 p-1 border rounded" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="search books or members"/></div>
          </div>
        </div>
      </div>
    );
  }

  function BooksView() {
    return (
      <div className="p-4">
        <h2 className="text-xl font-bold mb-2">Books</h2>
        <div className="flex gap-2 items-center mb-4">
          <AddBookInline onAdd={addBook} />
          <div className="flex items-center gap-2">
            <input placeholder="search books" value={query} onChange={(e)=>setQuery(e.target.value)} className="p-2 border rounded" />
            <select value={filter} onChange={(e)=>setFilter(e.target.value)} className="p-2 border rounded">
              <option value="all">All</option>
              <option value="available">Available</option>
              <option value="unavailable">Unavailable</option>
            </select>
          </div>
        </div>

        <div className="grid gap-3">
          {filteredBooks.map((b) => (
            <div key={b.id} className="p-3 border rounded flex justify-between items-center">
              <div>
                <div className="font-semibold">{b.title} <span className="text-sm font-normal">by {b.author}</span></div>
                <div className="text-sm opacity-70">ISBN: {b.isbn} • Year: {b.year}</div>
                <div className="text-sm mt-1">Available: {b.copies} / {b.totalCopies}</div>
              </div>
              <div className="flex gap-2">
                <button className="btn-ghost" onClick={() => {
                  const mId = prompt("Enter member ID to lend to (or leave blank to choose from list):");
                  if (!mId) return setTab("loans");
                  lendBook(b.id, mId);
                }}>Lend</button>
                <button className="btn-ghost" onClick={() => {
                  const newCopies = prompt("Set total copies:", String(b.totalCopies));
                  if (newCopies === null) return;
                  updateBook(b.id, { totalCopies: Number(newCopies), copies: Math.min(Number(newCopies), Number(b.copies)) });
                }}>Edit</button>
                <button className="text-red-600" onClick={() => { if (confirm("Remove book?")) removeBook(b.id); }}>Remove</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  function MembersView() {
    return (
      <div className="p-4">
        <h2 className="text-xl font-bold mb-2">Members</h2>
        <div className="flex gap-2 items-center mb-4">
          <AddMemberInline onAdd={addMember} />
          <input placeholder="search members" value={query} onChange={(e)=>setQuery(e.target.value)} className="p-2 border rounded" />
        </div>

        <div className="grid gap-3">
          {filteredMembers.map((m) => (
            <div key={m.id} className="p-3 border rounded flex justify-between items-center">
              <div>
                <div className="font-semibold">{m.name}</div>
                <div className="text-sm opacity-70">{m.email}</div>
                <div className="text-xs text-gray-500">Joined: {new Date(m.joined).toLocaleDateString()}</div>
              </div>
              <div className="flex gap-2">
                <button className="btn-ghost" onClick={() => setTab("loans")}>Loans</button>
                <button className="text-red-600" onClick={() => { if (confirm("Remove member?")) removeMember(m.id); }}>Remove</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  function LoansView() {
    return (
      <div className="p-4">
        <h2 className="text-xl font-bold mb-2">Loans</h2>
        <div className="mb-4 grid gap-2" style={{gridTemplateColumns: "repeat(auto-fit,minmax(160px,1fr))"}}>
          <div className="p-2 border rounded">
            <strong>Active Loans</strong>
            <div>{activeLoans.length}</div>
          </div>
          <div className="p-2 border rounded">
            <strong>Overdue</strong>
            <div>{overdueLoans.length}</div>
          </div>
          <div className="p-2 border rounded">
            <strong>Total Loans</strong>
            <div>{loans.length}</div>
          </div>
        </div>

        <div className="grid gap-3">
          {loans.map((l) => {
            const book = books.find((b) => b.id === l.bookId) || { title: "(deleted)" };
            const member = members.find((m) => m.id === l.memberId) || { name: "(deleted)" };
            return (
              <div key={l.id} className={`p-3 border rounded flex justify-between items-center ${l.returnedAt ? "opacity-60" : ""}`}>
                <div>
                  <div className="font-semibold">{book.title} — {member.name}</div>
                  <div className="text-sm opacity-70">Loaned: {new Date(l.loanedAt).toLocaleDateString()} • Due: {new Date(l.dueAt).toLocaleDateString()}</div>
                  {l.returnedAt && <div className="text-xs text-green-700">Returned: {new Date(l.returnedAt).toLocaleDateString()}</div>}
                </div>
                <div className="flex gap-2">
                  {!l.returnedAt && <button onClick={() => returnLoan(l.id)} className="btn-ghost">Return</button>}
                  <button onClick={() => navigator.clipboard?.writeText(l.id) && alert("Loan ID copied to clipboard")}>Copy ID</button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  // ------------------ Inline small forms ------------------
  function AddBookInline({ onAdd }) {
    const [open, setOpen] = useState(false);
    const [title, setTitle] = useState("");
    const [author, setAuthor] = useState("");
    const [year, setYear] = useState("");
    const [isbn, setIsbn] = useState("");
    const [copies, setCopies] = useState(1);

    function submit(e) {
      e?.preventDefault();
      if (!title || !author) return alert("Title and author required");
      onAdd({ title, author, year, isbn, copies });
      setTitle(""); setAuthor(""); setYear(""); setIsbn(""); setCopies(1); setOpen(false);
    }

    return (
      <div className="inline-block">
        {!open ? (
          <button className="btn btn-primary" onClick={() => setOpen(true)}>Add Book</button>
        ) : (
          <form onSubmit={submit} className="p-3 card rounded shadow" style={{display:"flex",gap:".5rem",alignItems:"flex-end"}}>
            <div>
              <label className="text-xs">Title</label>
              <input value={title} onChange={(e)=>setTitle(e.target.value)} className="block p-1 border rounded" />
            </div>
            <div>
              <label className="text-xs">Author</label>
              <input value={author} onChange={(e)=>setAuthor(e.target.value)} className="block p-1 border rounded" />
            </div>
            <div>
              <label className="text-xs">Year</label>
              <input value={year} onChange={(e)=>setYear(e.target.value)} className="block p-1 border rounded" style={{width: "5rem"}} />
            </div>
            <div>
              <label className="text-xs">Copies</label>
              <input type="number" min={1} value={copies} onChange={(e)=>setCopies(e.target.value)} className="block p-1 border rounded" style={{width: "5rem"}} />
            </div>
            <div style={{display:"flex",gap:".5rem"}}>
              <button className="btn btn-primary" type="submit">Save</button>
              <button type="button" className="btn-ghost" onClick={()=>setOpen(false)}>Cancel</button>
            </div>
          </form>
        )}
      </div>
    );
  }

  function AddMemberInline({ onAdd }) {
    const [open, setOpen] = useState(false);
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");

    function submit(e) {
      e?.preventDefault();
      if (!name) return alert("Name required");
      onAdd({ name, email });
      setName(""); setEmail(""); setOpen(false);
    }

    return (
      <div className="inline-block">
        {!open ? (
          <button className="btn" onClick={() => setOpen(true)}>Add Member</button>
        ) : (
          <form onSubmit={submit} className="p-3 card rounded shadow" style={{display:"flex",gap:".5rem",alignItems:"flex-end"}}>
            <div>
              <label className="text-xs">Name</label>
              <input value={name} onChange={(e)=>setName(e.target.value)} className="block p-1 border rounded" />
            </div>
            <div>
              <label className="text-xs">Email</label>
              <input value={email} onChange={(e)=>setEmail(e.target.value)} className="block p-1 border rounded" />
            </div>
            <div style={{display:"flex",gap:".5rem"}}>
              <button className="btn btn-primary" type="submit">Save</button>
              <button type="button" className="btn-ghost" onClick={()=>setOpen(false)}>Cancel</button>
            </div>
          </form>
        )}
      </div>
    );
  }

  // ------------------ App render ------------------
  return (
    <div className="min-h-screen" style={{background:"#f8fafc", color:"#111827"}}>
      <Header />
      <main className="max-w-6xl mx-auto p-4">
        <div className="mb-4" style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <div style={{display:"flex",gap:".5rem",alignItems:"center"}}>
            <input placeholder="global search" value={query} onChange={(e)=>setQuery(e.target.value)} className="p-2 border rounded" />
            <button onClick={() => { setQuery(""); setFilter("all"); }} className="btn-ghost">Clear</button>
          </div>
          <div className="text-sm" style={{opacity:.7}}>Local data saved to browser</div>
        </div>

        {tab === "dashboard" && <Dashboard />}
        {tab === "books" && <BooksView />}
        {tab === "members" && <MembersView />}
        {tab === "loans" && <LoansView />}

        <footer className="mt-8 p-4 text-center text-xs" style={{color:"#6b7280"}}>OakTown Library SPA — demo. Export/backup via browser DevTools localStorage key: {LS_KEY}</footer>
      </main>
    </div>
  );
}

// Minimal helper CSS classes in case Tailwind isn't available. You can remove these if using Tailwind.

/*
Optional: If not using Tailwind, you can include some small CSS to make the app pleasant.
Example CSS to include in index.css:

body { font-family: Inter, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial; }
.btn { padding: 0.5rem 0.75rem; border-radius: 0.5rem; border: 1px solid #ddd; background: #fff; cursor: pointer; }
.btn-primary { background: linear-gradient(90deg,#0ea5e9,#6366f1); color: white; border: none; }
.btn-ghost { background: transparent; border: 1px solid #ddd; }
.card { background: white; }
*/

