OakTown Library - React SPA
===========================

Quick start:

1. Install dependencies:
   npm install
2. Run dev server:
   npm run dev
3. Open the URL shown by Vite (usually http://localhost:5173)

This is a simple single-file React app (src/App.jsx) that demonstrates OOP-style models
and basic CRUD + lending features persisted to browser localStorage.
